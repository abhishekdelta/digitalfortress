This folder has 2 files. Both are same programs but are meant for different operating systems.
On linux-based systems, execute using ./encrypt
On windows-based systems, execute encrypt.exe from command prompt.
