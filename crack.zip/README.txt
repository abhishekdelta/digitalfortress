The application needs .NET Framework for running.
If you dont have it installed in your computer , Please install the same from the Microsoft Website .
